These are some sample ASCII STL files to use with the viewer. Select using the open file dialog box.
